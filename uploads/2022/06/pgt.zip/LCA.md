```cpp
struct LCA
{//先调用dfs预处理，然后lca求lca，dis求两点距离
    int f[200010][21];
    int d[200010];
    int root;

    LCA(int root = 1) :root(root) {}

    void dfs(int x, int fa)
    {
        f[x][0] = fa;
        d[x] = d[fa] + 1;
        for (int i = 1; (1 << i) <= d[x]; i++)
        {
            f[x][i] = f[f[x][i - 1]][i - 1];
        }
        for (auto it : e[x])
        {
            if (it == fa) continue;
            dfs(it, x);
        }
    }
    
    int lca(int x, int y)
    {
        if (d[x] < d[y]) swap(x, y);
        while (d[x] > d[y]) x = f[x][(int)log2(d[x] - d[y])];
        if (x == y) return x;
        for (int k = (int)log2(d[x]); k >= 0; k--)
        {
            if (f[x][k] != f[y][k]) x = f[x][k], y = f[y][k];
        }
        return f[x][0];
    }

    int dis(int x, int y)
    {
        int t = lca(x, y);
        return d[x] + d[y] - d[t] * 2;
    }
};
```

