```cpp
/*
gcd(-a,b)=gcd(a,b)
gcd(a,b)=gcd(b,a%b) 辗转相除
gcd(a,b)=gcd(b,a-b) 更相减损
gcd(ka,kb)=k*gcd(a,b)
gcd(a/b,b/m)=gcd(a,b)/m
gcd(a+mb,b)=gcd(a,b)
gcd(ab,m)=gcd(a,m)*gcd(b,m)
一个数存在乘法逆元的条件是与模数互质
*/
struct Exgcd
{
	ll exgcd(ll a, ll b, ll& x, ll& y)
	{
		if (!b)
		{
			x = 1;
			y = 0;
			return a;
		}
		ll t = exgcd(b, a % b, y, x);
		y -= x * (a / b);
		return t;
	}
	pair<ll, ll> get(ll a, ll b, ll c)	
	{//求方程ax+by=c的特解，无解返回-1
	 //即ax(mod b)==c的最小整数解（可能为负数需要+b再%b）
	 //同时也是by(mod a)==c的最小整数解（可能为负数需要+a再%a）
     //需要使ab互质才能达到最小整数解，需x的最小解则b/=gcd(a,b)，需要y的则a/=gcd(a,b)
		ll x = 0;
		ll y = 0;
		ll g = exgcd(a, b, x, y);
		if(c%g) return make_pair(-1,-1);
		x *= c / g;
		y *= c / g;
		return make_pair(x, y);
	}
	ll get(ll a, ll mod)	//a在模mod下的乘法逆元
	{
		ll x = 0;
		ll y = 0;
		exgcd(a, mod, x, y);
		return (x % mod + mod) % mod;
	}
};

ll fpro(ll x,ll y,ll p)
{
    ll z=(double)x/p*y;
    ll res=(ull)x*y-(ull)z*p;
    return (res+p)%p;
}

//拓展中国剩余定理,返回值为对于多组a,p未知数x≡a(mod p)的最小非负整数解,无解返回-1
ll excrt(vector<ll>& a, vector<ll>& p)
{
	ll lcm = p[0];
	ll res = a[0];
	Exgcd e;
	for (int i = 1; i < (int)a.size(); i++)
	{
		ll x, y;
		ll c = (a[i] - res % p[i] + p[i]) % p[i];
		ll g = e.exgcd(lcm, p[i], x, y);
		if (c % g) return -1; //无解
		x = fpro(x, c / g, p[i] / g);
		res += x * lcm;
		lcm *= p[i] / g;
		((res %= lcm) += lcm) %= lcm;
	}
	return ((res %= lcm) += lcm) %= lcm;
}
```

