```cpp
int e[1000010][26];
//vector<int>ind[10000010];
int cnt = 1;

void trieinsert(string s, int p)
{
	int u = 0;
	for (int i = 0; i < (int)s.length(); i++)
	{
		int v = s[i] - 'A';
		if (!e[u][v]) e[u][v] = cnt++;
		u = e[u][v];
	}
	//ind[u].emplace_back(p);
}
```

