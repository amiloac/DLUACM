```cpp
bool np[(int)1e6 + 10];
vector<int>prime;
int res[(int)1e3 + 10][(int)1e3 + 10];
int d[(int)1e6 + 10][5];    //合法的分解

void getprime(int r)
{
    np[0] = np[1] = true;
    mfor(i, 2, r)
	{
        if (!np[i])	prime.emplace_back(i);
        for (auto it : prime)
		{
			if (i * it > r) break;
			np[i * it] = true;
			if (i % it == 0) break;
		}
	}
}

void getgcds(int r) //获取[1,r]内所有数的预处理gcd数组res和合法分解d
{
    d[1][0] = d[1][1] = d[1][2] = 1;
    mfor(i, 2, r)
    {
        if (!np[i])
        {
            d[i][0] = d[i][1] = 1;
            d[i][2] = i;
        }
        for (int j = 0; prime[j] * i <= r; j++)
        {
            int t = prime[j] * i;
            d[t][0] = d[i][0] * prime[j];
            d[t][1] = d[i][1];
            d[t][2] = d[i][2];
            sort(d[t], d[t] + 3);
            if (i % prime[j] == 0) break;
        }
    }
    int x = sqrt(r);
    mfor(i, 0, x)
    {
        res[0][i] = res[i][0] = i;
    }
    for (int i = 1; i <= x; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            res[i][j] = res[j][i] = res[j][i % j];
        }
    }
}

int getans(int a, int b)
{
    int ans = 1;
    for (int i = 0; i < 3; i++)
    {
        int t;
        if (d[a][i] > 1e3)
        {
            if (b % d[a][i]) t = 1;
            else t = d[a][i];
        }
        else t = res[d[a][i]][b % d[a][i]];
        b /= t;
        ans *= t;
    }
    return ans;
}
```

