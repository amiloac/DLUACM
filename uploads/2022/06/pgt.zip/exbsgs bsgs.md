```cpp
struct Exgcd
{
	long long exgcd(long long a, long long b, long long& x, long long& y)
	{
		if (!b)
		{
			x = 1;
			y = 0;
			return a;
		}
		ll t = exgcd(b, a % b, y, x);
		y -= x * (a / b);
		return t;
	}
	pair<long long, long long> get(long long a, long long b, long long c)	
	{//求方程ax+by=c的特解，无解返回inf
	 //即ax(mod b)==c的最小整数解（可能为负数需要+b再%b）
	 //同时也是by(mod a)==c的最小整数解（可能为负数需要+a再%a）
     //需要使ab互质才能达到最小整数解，需x的最小解则b/=gcd(a,b)，需要y的则a/=gcd(a,b)
		long long x = 0;
		long long y = 0;
		long long t = exgcd(a, b, x, y);
		if (c % t) return make_pair(0x3f3f3f3f3f3f3f3f, 0x3f3f3f3f3f3f3f3f);
		x *= c / t;
		y *= c / t;
		return make_pair(x, y);
	}
	long long get(long long a, long long mod)	//a在模mod下的乘法逆元
	{//模mod意义下除以a因为除法(x/a)%mod!=(x%mod/a%mod)%mod
	 //所以有模除以a就需要乘以a的逆元即模mod意义下x/a==x*get(a)
     //当a与m不互质时逆元不存在
		long long x = 0;
		long long y = 0;
		exgcd(a, mod, x, y);
		return (x % mod + mod) % mod;
	}
};

ll fpow(ll a,ll n,ll mod)
{
    ll res = 1;
    while(n)
    {
        if(n & 1)
        {
            res = res % mod * a % mod;
        }
        a = a % mod * a % mod;
        n >>= 1;
    }
    return res; 
}

ll bsgs(ll a, ll b, ll mod, ll k = 1) 
{//求解a^x ≡ b(mod p)的x p必须为质数
    //直接使用bsgs时k=1
    if(b%gcd(a,mod)) return -1;
	unordered_map<ll, ll>s;
	ll p = ceil(sqrt(mod));
	Exgcd e;
	b = (b * e.get(k, mod)) % mod;
	ll t = fpow(a, p, mod);
	t = e.get(t, mod);
	ll pro = 1;
	for (ll i = 0; i <= p; i++)
	{
		if (!s.count(pro)) s[pro] = i;
		(pro *= a) %= mod;
	}
	pro = b;
	for (ll i = 0; i <= p; i++)
	{
		if (s[pro]) return i * p + s[pro];
		(pro *= t) %= mod;
	}
	return -1;
}

ll exbsgs(ll a, ll b, ll mod)
{//求解a^x ≡ b(mod p)的x p可以是任意数字
	ll x = 1;
	ll k = 0;
	ll p = gcd(a, mod);
	if (b == 1) return 0;
	while (p > 1) 
	{
		if (b % p) return -1;
		k++;
		b /= p, mod /= p;
		x = x * (a / p) % mod;
		if (x == b) return k;
		p = gcd(a, mod);
	}
	ll res = bsgs(a, b, mod, x);
	if (!~res) return -1;
	return res + k;
}
```

