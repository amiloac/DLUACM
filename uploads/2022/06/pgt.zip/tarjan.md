```cpp
struct Tarjan
{
    Graph& g;
    int dfn[maxn]; //第i个点被dfs到次序
    int low[maxn];    //二叉搜索树上i所在子数上仍在栈中的最小dfn，low[i]相等的点在一个强连通分量中
    bool vis[maxn];
    stack<int>s;
    int tot=0;
    int cnt=0;
    int res[maxn];    //储存强连通分量，res[i]表示点i属于第res[i]个强连通分量
    int num[maxn]; //第i个强连通分量的点数

    Tarjan(Graph& g) :g(g) {}

    void clear()
    {
        tot = 0;
        cnt = 0;
        memset(num, 0, sizeof(num));
        memset(dfn, 0, sizeof(dfn));
        memset(low, 0, sizeof(low));
    }

    void tarjan(int x)
    {
        dfn[x] = low[x] = ++cnt;
        s.push(x);
        vis[x] = true;
        for (int i = g.head[x]; ~i; i = g.e[i].nxt)
        {
            int v = g.e[i].v;
            if (!dfn[v])
            {
                tarjan(v);
                low[x] = min(low[x], low[v]);
            }
            else if (vis[v])
            {
                low[x] = min(low[x], dfn[v]);
            }
        }
        if (low[x] == dfn[x])
        {
            tot++;
            while (!s.empty() && s.top() != x)
            {
                int t = s.top();
                res[t] = tot;
                num[tot]++;
                vis[t] = false;
                s.pop();
            };
            s.pop();
            res[x] = tot;
            num[tot]++;
            vis[x] = false;
        }
    }
};
```

