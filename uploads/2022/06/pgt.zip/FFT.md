```cpp
ll rev[maxn];

//注意：使用 getFFT之后b数组中的值不是原值

void FFT(complex<ld> * s, int f, int n)
{
    const double pi = acos(-1);
    for (ll i = 0; i < n; i++)
    {
        if (i < rev[i]) swap(s[i], s[rev[i]]);
    }
    for (ll i = 1; i < n; i <<= 1)
    {
        complex<ld> wn(cos(pi / i), f * sin(pi / i));
        ll p = i << 1;
        for (ll j = 0; j < n; j += p)
        {
            complex<ld> w(1, 0);
            for (ll k = 0; k < i; k++)
            {
                complex<ld> x = s[j + k];
                complex<ld> y = w * s[j + k + i];
                s[j + k] = x + y;
                s[j + k + i] = x - y;
                w *= wn;
            }
        }
    }
}

void getFFT(complex<ld> * a, complex<ld> * b, int n, int m)
{
    int l = 0;
    m += n;
    for (n = 1; n <= m; n <<= 1) l++;
    for (ll i = 0; i < n; i++) rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (l - 1));
    FFT(a, 1, n);
    FFT(b, 1, n);
    for (ll i = 0; i <= n; i++) a[i] = a[i] * b[i];
    FFT(a, -1, n);
    for (ll i = 0; i <= n; i++) a[i] /= n;
}
```

