```cpp
struct Spfa
{
    Graph& g;
    int dis[maxn];
    bool vis[maxn];
    queue<int>q;

    Spfa(Graph& g) :g(g) {}

    void spfa(int x)
    {
        memset(dis, 0x3f, sizeof(dis));
        memset(vis, false, sizeof(vis);
        dis[x] = 0;
        q.push(x);
        vis[x] = true;
        while (!q.empty())
        {
            int t = q.front();
            q.pop();
            vis[t] = false;
            for (int i = g.head[t]; i != -1; i = g.e[i].nxt)
            {
                int v = g.e[i].v;
                int w = g.e[i].w;
                if (dis[v] > dis[t] + w)
                {
                    dis[v] = dis[t] + w;
                    if (!vis[v])
                    {
                        q.push(v);
                        vis[v] = true;
                    }
                }
            }
        }
    }
};
```

