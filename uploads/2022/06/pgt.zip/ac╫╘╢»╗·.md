```cpp
struct tnode 
{
	int nxt[26];
	int fail;
	int flag;
	int ans;
}trie[maxn];

queue<int>q;
void insert(string s, int num) 
{
	int u = 1;
	int len = s.length();
	for (int i = 0; i < len; ++i) 
	{
		int v = s[i] - 'a';
		if (!trie[u].nxt[v]) trie[u].nxt[v] = ++cnt;
		u = trie[u].nxt[v];
	}
	if (!trie[u].flag) trie[u].flag = num;
	pos[num] = trie[u].flag;
}

void getFail() 
{
	for (int i = 0; i < 26; i++) trie[0].nxt[i] = 1;
	q.push(1);
	while (!q.empty()) 
	{
		int u = q.front();
		q.pop();
		int Fail = trie[u].fail;
		for (int i = 0; i < 26; ++i) 
		{
			int v = trie[u].nxt[i];
			if (!v) 
			{
				trie[u].nxt[i] = trie[Fail].nxt[i];
				continue;
			}
			trie[v].fail = trie[Fail].nxt[i];
			ind[trie[v].fail]++;
			q.push(v);
		}
	}
}

void topo() 
{
	for (int i = 1; i <= cnt; ++i)
	{
		if (ind[i] == 0) q.push(i);
	}
	while (!q.empty()) 
	{
		int u = q.front();
		q.pop();
		vis[trie[u].flag] = trie[u].ans;
		int v = trie[u].fail; 
		ind[v]--;
		trie[v].ans += trie[u].ans;
		if (!ind[v]) q.push(v);
	}
}

void query(string s)
{
	int u = 1;
	int len = s.length();
	for (int i = 0; i < len; i++)
	{
		u = trie[u].nxt[s[i] - 'a'];
		trie[u].ans++;
	}
}
//先insert 再getFail 然后query 然后topo 最后vis[pos[i]]为第i个query的字符串的数量
```

