```cpp
struct Manacher
{
	int p[maxn];
	void init(string& s)
	{
		string t;
		t.push_back(1);
		for (auto it : s)
		{
			t.push_back(2);
			t.push_back(it);
		}
		t.push_back(2);
		t.push_back(0);
		s = t;
	}

	int manacher(string s)
    {
		if (s.empty()) return 0;
		if (s.size() == 1) return 1;
		init(s);
		int mxl = -1;
		string res;
		int id = 0;
		int mx = 0;
		for (int i = 1; i < (int)s.length() - 1; i++)
		{
			if (i < mx) p[i] = min(p[2 * id - i], mx - i);
			else p[i] = 1;
			while (s[i - p[i]] == s[i + p[i]]) p[i]++;
			if (mx < i + p[i]) 
			{
				id = i;
				mx = i + p[i]; 
			}
			mxl = max(mxl, p[i] - 1);
            //可以增加string res=s.substr(i-p[i]+1,p[i]*2+1)及以下代码求出最长回文子串
            //string t;
			//for (auto it : res) if (it != 1 && it && it != 2) t.push_back(it);
			//return t;
		}
		return mxl;
	}
	void clear()
	{
		mem(p, 0);
	}
};
```

