```cpp
struct KMP 
{//下标从1开始
	int nxt[maxn];
	string s;

	void getnxt() 
	{
		nxt[1] = 0;
		for (int i = 2, j = 0; i < (int)s.length(); i++) 
		{
			while (j > 0 && s[i] != s[j + 1]) j = nxt[j];
			if (j < (int)s.length() - 1 && s[j + 1] == s[i]) j++;
			nxt[i] = j;
		}
	}

	int kmp(string t) 
	{
		int i = 1;
		int j = 1;
		while (i < (int)s.length() && j < (int)t.length()) 
		{
			if (j <= 0 || s[i] == t[j]) i++, j++;
			else j = nxt[j];
		}
		if (j >= (int)t.length()) return i - j + 1;
		else return -1;
	}
    //当i-nxt[i]能整除i时，s[1]~s[i-nxt[i]]就是s前i-1个字符的最小循环元。
    //若可以有非完整循环节则i-nxt[i]即可
    //循环次数为i/(i-nxt[i]).
}sol;
```

