```cpp
struct Tarjan_cut
{
	Graph& g;
	int dfn[maxn];
	int low[maxn];
	bool cut[maxn];
    int ans[maxn];
	int tot;

	Tarjan_cut(Graph& g) :g(g), tot(0) {}

	void clear()
	{
		memset(dfn, 0, sizeof(dfn));
		memset(low, 0, sizeof(low));
		memset(cut, 0, sizeof(cut));
		tot = 0;
	}

	void tarjan(int x, int root)
	{//调用：tarjan(x,x)
        ans[x]=-1;
		dfn[x] = low[x] = ++tot;
		int son = 0;
		for (int i = g.head[x]; ~i; i = g.e[i].nxt)
		{
			int v = g.e[i].v;
			if (!dfn[v])
			{
				tarjan(v, root);
				low[x] = min(low[x], low[v]);
				if (low[v] >= dfn[x] && x != root) cut[x] = true,ans[x]++;
				if (x == root) son++;
			}
			low[x] = min(low[x], dfn[v]);
		}
		if (son >= 2 && x == root) cut[x] = true,ans[x]=son-1;
	}
};
```

