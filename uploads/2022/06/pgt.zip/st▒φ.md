```cpp
struct STE
{//可以维护max，min等，查询O(1)预处理O(nlogn)
	int st[maxn][50];
	int lg[maxn];

	void init(int n, int* a)
	{
		lg[0] = -1;
		for (int i = 1; i <= n; i++) st[i][0] = a[i], lg[i] = lg[i / 2] + 1;
		for (int i = 1; i <= lg[n]; i++)
		{
			for (int j = 1; j + (1 << i) - 1 <= n; j++)
			{
				st[j][i] = max(st[j][i - 1], st[j + (1 << (i - 1))][i - 1]);
			}
		}
	}

	inline int getmax(int l, int r)
	{
		int len = lg[r - l + 1];
		return max(st[l][len], st[r - (1 << len) + 1][len]);
	}
};

```

