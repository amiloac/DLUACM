```cpp
const ll mod = 998244353;
const ll G = 3;
//G为mod的原根
//G为3时常见的mod：998244353,1004535809,469762049
ll rev[maxn];

//注意：getNTT之后b数组的值不是原值

long long fpow(long long a, long long n, long long mod)
{
	if (n == 0) return 1;
	else if (n & 1) return a * fpow(a, n - 1, mod) % mod;
	else
	{
		long long num = fpow(a, n / 2, mod) % mod;
		return num * num % mod;
	}
}

void NTT(ll* s, int f, int n)
{
	for (ll i = 0; i < n; i++)
	{
		if (i < rev[i]) swap(s[i], s[rev[i]]);
	}
	for (ll i = 1; i < n; i <<= 1)
	{
		ll wn = fpow(G, (mod - 1) / (i << 1), mod);
		if (!~f) wn = fpow(wn, mod - 2, mod);
		ll p = i << 1;
		for (ll j = 0; j < n; j += p)
		{
			ll w = 1;
			for (ll k = 0; k < i; k++)
			{
				ll x = s[j + k];
				ll y = w * s[j + k + i];
				s[j + k] = x + y;
				s[j + k] %= mod;
				s[j + k + i] = x - y;
				s[j + k + i] %= mod;
				(s[j + k + i] += mod) %= mod;
				w *= wn;
				w %= mod;
			}
		}
	}
}

void getNTT(ll* a, ll* b, int n, int m)
{
	int l = 0;
	m += n;
	for (n = 1; n <= m; n <<= 1) l++;
	for (ll i = 0; i < n; i++) rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (l - 1));
	NTT(a, 1, n);
	NTT(b, 1, n);
	for (ll i = 0; i <= n; i++) a[i] = a[i] * b[i], a[i] %= mod;
	NTT(a, -1, n);
	ll inv = fpow(n, mod - 2, mod);
	for (int i = 0; i <= m; i++) a[i] *= inv, a[i] %= mod;
}
```

