```cpp
struct Tarjan_brg
{//cnt必须从-1开始（即第一条有效边为g.e[0])
 //即无向图的双向边编号可以通过^1相互得到
	Graph& g;
	int dfn[maxn];
	int low[maxn];
	vector<intpair>b;
	int tot;
	int bnt;

	Tarjan_brg(Graph& g) :g(g), tot(0) {}

	void clear()
	{
		memset(dfn, 0, sizeof(dfn));
		memset(low, 0, sizeof(low));
		tot = 0;
	}

	void tarjan(int x, int lst)
	{//调用：tarjan(x,x)
		dfn[x] = low[x] = ++tot;
		for (int i = g.head[x]; ~i; i = g.e[i].nxt)
		{
			if (i == lst) continue;
			int v = g.e[i].v;
			if (!dfn[v])
			{
				tarjan(v, i);
				low[x] = min(low[x], low[v]);
				if (low[v] > dfn[x]) bnt++, b.emplace_back(x, v);
				//具体的桥：x-v
			}
			else if (i != (lst ^ 1)) low[x] = min(low[x], dfn[v]);
		}
	}
}tjn(g);
```

