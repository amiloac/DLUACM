```cpp
struct STtree
{
//默认min add功能
//query功能修改push_up cmp
//update功能修改push_down update
//greater功能修改greater
#define lc(x) x<<1
#define rc(x) x<<1|1
    struct tree
    {
        int a;
        int l, r;
        int tag;
        tree() :tag(0), l(0), r(0), a(0) {}
    }node[maxn << 2];
    
    STtree(){}
    
    STtree(int l, int r, int* a)
    {
        build(1, l, r, a);
    }

    inline void push_up(int x)
    {
        //query功能
        node[x].a = min(node[lc(x)].a, node[rc(x)].a);
    }

    inline int cmp(int a, int b)
    {
        //query功能
        return (a < b ? a : b);
    }

    void build(int x, int l, int r, int* a)
    {
        node[x].l = l;
        node[x].r = r;
        node[x].tag = 0;
        if (l == r)
        {
            if (!a) node[x].a = 0;
            else node[x].a = a[l];
            return;
        }
        int mid = (l + r) >> 1;
        build(lc(x), l, mid, a);
        build(rc(x), mid + 1, r, a);
        push_up(x);
    }
    void push_down(int x)
    {
        node[lc(x)].tag += node[x].tag;
        node[lc(x)].a += node[x].tag;
        node[rc(x)].a += node[x].tag;
        node[rc(x)].tag += node[x].tag;
        node[x].tag = 0;
    }
    void update(int left, int right, int x, int k)
    {
        if (left <= node[x].l && node[x].r <= right)
        {
            node[x].a += k;
            node[x].tag += k;
            return;
        }
        push_down(x);
        int mid = (node[x].l + node[x].r) >> 1;
        if (left <= mid) update(left, right, lc(x), k);
        if (right > mid) update(left, right, rc(x), k);
        push_up(x);
    }
    int query(int left, int right, int x)
    {
        int res = 0x3f3f3f3f;
        if (left <= node[x].l && node[x].r <= right) return node[x].a;
        int mid = (node[x].l + node[x].r) >> 1;
        push_down(x);
        if (left <= mid) res = cmp(res, query(left, right, lc(x)));
        if (right > mid) res = cmp(res, query(left, right, rc(x)));
        return res;
    }

    int greater(int left, int right, int x, int v)
    {
        //区间内第一个大于v的数字的下标
        //没有返回-1
        if (node[x].l == node[x].r)
        {
            if (node[x].a > v) return node[x].l;
            else return -1;
        }
        if (node[x].a <= v)  return -1;
        int t=-1;
        int mid=(node[x].l+node[x].r)>>1;
        if(left<=mid)
        {
            t=greater(left, right, lc(x), v);
        	if (~t)  return t;
        }
        if(right>mid) t=greater(left, right, rc(x), v);
        return t;
    }
};
```

