```cpp
struct Dijstra
{
	struct cmp_dij
	{
		bool operator ()(const pair<ll, ll>& a, const pair<ll, ll>& b)const
		{
			return a.second > b.second;
		}
	};

	Graph& g;
	ll dis[maxn];
	bool vis[maxn];
	priority_queue<pair<ll, ll>, vector<pair<ll, ll>>, cmp_dij>q;

	Dijstra(Graph& g) :g(g) {}

	void dijstra(ll x)
	{
		memset(dis, 0x3f, sizeof(dis));
		memset(vis, false, sizeof(vis));
		dis[x] = 0;
		q.push(make_pair(x, dis[x]));
		while (!q.empty())
		{
			pair<ll, ll> t = q.top();
			q.pop();
			if (vis[t.first]) continue;
			vis[t.first] = true;
			for (int i = g.head[t.first]; i != -1; i = g.e[i].nxt)
			{
				ll v = g.e[i].v;
				ll w = g.e[i].w;
				if (!vis[v] && dis[v] > t.second + w)
				{
					dis[v] = t.second + w;
					q.push(make_pair(v, dis[v]));
				}
			}
		}
	}
};
```

