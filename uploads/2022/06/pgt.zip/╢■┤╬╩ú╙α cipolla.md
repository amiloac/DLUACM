```cpp
bool check_if_residue(ll x)
{
	return power(x, (mod - 1) >> 1) == 1;
}

long long fpow(long long a, long long n, long long mod)
{
	if (n == 0)        return 1;
	else if (n & 1) return a * fpow(a, n - 1, mod) % mod;
	else
	{
		long long num = fpow(a, n / 2, mod) % mod;
		return num * num % mod;
	}
}

bool get_res(ll n, ll p, ll& x0, ll& x1)
{//cipolla算法，p必须为奇素数，求解x²≡n(mod p)的解
 //解为x0和x1，顺序不一定按模p意义下的大小顺序
 //需要虚数模板
 //无解返回false
	if (fpow(n, (p - 1) / 2, p) != 1) return false;
	mod = p;
	ll a = rand() % mod;
	while (!a || check_if_residue((a * a + mod - n) % mod))
		a = rand() % mod;
	imul = (a * a + mod - n) % mod;
	x0 = ll(power(complex(a, 1), (mod + 1) >> 1).rel);
	x1 = mod - x0;
	return true;
}
```

