```cpp
int f[maxn],SG[maxn],S[maxn];
void  getSG(int n) {
	int i,j;
	//memset(SG,0,sizeof(SG));
	for(i = 1; i <= n; i++) {
		memset(S,0,sizeof(S));
		for(j = 0; f[j] <= i && j <= N; j++)
			S[SG[i-f[j]]] = 1;  //将后继状态的SG函数值进行标记
		for(j = 0;; j++) if(!S[j]) {  //查询当前后继状态SG值中最小的非零值
				SG[i] = j;
				break;
		}
	}
}
```

## ACWing 235. 魔法珠

Freda 和 rainbow 是超自然之界学校(Preternatural Kingdom University，简称PKU)魔法学院的学生。

为了展示新学的魔法，他们决定进行一场对弈。

起初 Freda 面前有 $n$ 堆魔法珠，其中第 $i$ 堆有 $a_i$ 颗。

Freda 和 rainbow 可以轮流进行以下操作：

1. 选择 $n$ 堆中魔法珠数量大于 $1$ 的任意一堆。记该堆魔法珠的数量为 $p$，$p$ 有 $b_1,b_2,....,b_m$ 共 $ m$个小于 $p$ 的约数。
2. 施展魔法把这一堆魔法珠变成 $m$ 堆，每堆各有 $b_1,b_2,....,b_m$ 颗魔法珠。
3. 选择这 $m$ 堆中的一堆魔法珠，施展魔法令其消失。

注意一次操作过后，魔法珠的堆数会增加 $m−2$，各堆中魔法珠数量的总和可能会发生变化。

当轮到某人操作时，如果每堆中魔法珠的数量均为 $1$，那么他就输了。

Freda 和 rainbow 都采取最好的策略，从 Freda 开始。

请你预测一下，谁能获胜呢？

#### 分析

显然质数是必败态，$sg_{i\in prime}=0$

一个数字的后续状态是所有不同的 $m-1$ 个约数的组合，所以其 $sg$ 函数值应当是其所有不同的 $m-1$ 个约数组合中 $sg$ 值异或和的 $mex$

```cpp
#include<bits/stdc++.h>
using namespace std;

int sg[1010];
bool np[1010];
int a[1010];

int getsg(int x) {
	if(~sg[x]) return sg[x];
	if(!np[x]) return 0;
	vector<int>s;
	for(int i=1; i*i<=x; i++) {
		if(x%i) continue;
		s.emplace_back(i);
		if(i*i!=x&&i!=1) s.emplace_back(x/i);
	}
	unordered_set<int>ext;
	for(auto it:s) {
		int t=0;
		for(auto v:s) {
			if(it==v) continue;
			t^=getsg(v);
		}
		ext.emplace(t);
	}
	int res=0;
	while(ext.count(res)) res++;
	return sg[x]=res;
}

int main() {
	int n;
	memset(sg,-1,sizeof sg);
	for(int i=1; i<=1000; i++) {
		if(np[i]) continue;
		int pro=i*2;
		while(pro<=1000) np[pro]=true,pro+=i;
	}
	while(~scanf("%d",&n)) {
		for(int i=1; i<=n; i++) scanf("%d",a+i);
		int ans=0;
		for(int i=1; i<=n; i++) ans^=getsg(a[i]);
		if(ans) puts("freda");
		else puts("rainbow");
	}
}
```

